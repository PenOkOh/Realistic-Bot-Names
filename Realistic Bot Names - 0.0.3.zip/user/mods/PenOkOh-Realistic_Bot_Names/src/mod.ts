import { DependencyContainer } from "tsyringe";
import { IPostDBLoadMod } from "@spt/models/external/IPostDBLoadMod";
import { DatabaseServer } from "@spt/servers/DatabaseServer";
import { ILogger } from "@spt/models/spt/utils/ILogger";
import { LogTextColor } from "@spt/models/spt/logging/LogTextColor";

class RealisticBotNames implements IPostDBLoadMod
{

    private bearCFG = require("../cfg/BEAR.json");
    private usecCFG = require("../cfg/USEC.json");

    public postDBLoad(container: DependencyContainer): void 
    {
        // Apparently the logger was in the container. Weird one innit?
        const logger = container.resolve<Ilogger>("WinstonLogger");

        // Calling database stuff ftw yo!
        const db = container.resolve<DatabaseServer>("DatabaseServer");      
        const bot = db.getTables().bots.types;
        const bearNames = this.bearCFG['Names'];
        const usecNames = this.usecCFG['Names'];

        bot["bear"].firstName = bearNames
        bot["bear"].surName = bearNames
        bot["usec"].firstName = usecNames
        bot["usec"].surName = usecNames

        // Log stuff and things, you know, log and stuff and things, aye?
        logger.logWithColor(`[PenOkOh-RBN] Attempting To Load Realistic Bot Names...`, LogTextColor.GREEN);
        logger.logWithColor(`[PenOkOh-RBN] Importing BEAR names from the extensive directory...`, LogTextColor.CYAN);
        logger.logWithColor(`[PenOkOh-RBN] Importing USEC names from the extensive directory...`, LogTextColor.CYAN);
        logger.logWithColor(`[PenOkOh-RBN] All names have successfully loaded without issues!`, LogTextColor.GREEN);
        logger.debug(`[${this.mod}] postDb Loaded`);

    }
}

module.exports = { mod: new RealisticBotNames() }